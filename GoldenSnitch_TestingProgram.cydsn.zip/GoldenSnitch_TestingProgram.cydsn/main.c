/* ========================================
ME 235 Class Project : Design of Microprocessor Based Mechanical Systems
Last Update : 13 May 2020
Students : 
Martin BANET-RIVET (martin_banet@berkeley.edu)
Remi LE THAI (remi.lethai@berkeleley.edu)
Elise PEREZ (eliseperezylandazuri@berkeley.edu)
Tiffany TAO (tifftao@berkeley.edu)
 * ========================================
*/
#include <project.h>
#include <mpu6050.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>

#include "project.h"

/* Parameters definitions*/
//Generalities

char TransmitBuffer[200];
#define numberOfTests 30;
#define sensitivityG 131.07; //deg s-1
#define sensitivityA 16384;  // G
int i; 

// Ultra sonic sensors
uint16_t dist1;
uint16_t counts1;
uint16_t dist2;
uint16_t counts2;
uint16_t button_flag=1;
uint16_t distmax=50; // mm 


// PWM

char rxData; //Character given by the user through LabVIEW that is collected by BLE
int CW = 100;
int CCW = 2200;
int delaySpeed = 10;
int PMW1_Value;

// IMU 

#define sensitivityG 131.07; //deg s-1
#define sensitivityA 16384;  // G

int16_t CAX, CAY, CAZ; //current acceleration values
int16_t CGX, CGY, CGZ; //current gyroscope values
   
float   AXoff, AYoff, AZoff; //accelerometer offset values
float   GXoff, GYoff, GZoff; //gyroscope offset values

float   raw_AX, raw_AY, raw_AZ; //acceleration floats
float   raw_GX, raw_GY, raw_GZ; //gyroscope floats

float   AX, AY, AZ; //acceleration floats
float   GX, GY, GZ; //gyroscope floats

float m=1;
float g=9.81;
float k=1;
float b=1;
float Ixx=1,Iyy=1,Izz=1;
float L=1;

double Ome[5]={0.,0.,0.,0.,0.};


double OmegaRange1=120; //deg s-1
double OmegaRange2=200; //deg s-1 
double OmegaRange3=300; //deg s-1



void AngVelo(int raw_gx,int raw_gy,int raw_gz,double pulse[] )
{
    double gx=raw_gx/sensitivityG; //deg s-1
    double gy=raw_gy/sensitivityG; //deg s-1
    double gz=raw_gz/sensitivityG; //deg s-1
    gx=gx*3.141592/180; //rad s-1
    gy=gy*3.141592/180; //rad s-1
    gz=gz*3.141592/180; //rad s-1
    
    pulse[0]=1; // GAMMA calculation
    pulse[1]=((m*g)/(4*k*cos(gx)*cos(gy)))-((2*b*exp(gx)*Ixx+exp(gz)*Izz*k*L)/(4*b*k*L));
    pulse[2]= ((m*g)/(4*k*cos(gx)*cos(gy)))+((exp(gz)*Izz)/(4*b))-((exp(gy)*Iyy)/2*k*L);
    pulse[3] =((m*g)/(4*k*cos(gx)*cos(gy)))-((-2*b*exp(gx)*Ixx+exp(gz)*Izz*k*L)/(4*b*k*L));
    pulse[4]= ((m*g)/(4*k*cos(gx)*cos(gy)))+((exp(gz)*Izz)/(4*b))+((exp(gy)*Iyy)/2*k*L);
    //sprintf(TransmitBuffer,"%f,%f,%f,%f \r\n",gamma[1],gamma[2],gamma[3],gamma[4]);
    //UART_PutString(TransmitBuffer);
    
    for(i=0;i<=4;i++)
    {pulse[i]=sqrt(fabs(pulse[i])); // OMEGA calculation
    pulse[i]=pulse[i]*180/3.1415192; // deg s-1 but if commented rad s-1 WARNING need to consistent with Omega range
    }
    //sprintf(TransmitBuffer,"%f,%f,%f,%f \r\n",pulse[1],pulse[2],pulse[3],pulse[4]); 
    //UART_PutString(TransmitBuffer);
}

void RotationMotor (double pulse[])
{
// Adapt the Motor velocity according to the MPU angle, motor 1 and 3, 2 and 4 have the same behaviour respectively
    if  (pulse[1]<= OmegaRange1 || pulse[3]<= OmegaRange1) //under 120
            {
                PWM1_Start();
                PWM1_WriteCompare(1100);// motor goes CW slow
                PWM2_Start();
                PWM2_WriteCompare(1100);// motor goes CW slow
                //UART_PutString("FAST\r\n");
            }
    if ( (OmegaRange1<=pulse[1]  && pulse[1]<= OmegaRange2) || (OmegaRange1<=pulse[3]  && pulse[3]<= OmegaRange2) ) // check same units 
    {
        PWM1_Start();
        PWM1_WriteCompare(1500);// motor goes CW fast
        PWM2_Start();
        PWM2_WriteCompare(1500);// motor goes CW fast
        //UART_PutString("SLOW\r\n");
    }
    if ( (OmegaRange2<=pulse[1]  && pulse[1]<= OmegaRange3) || (OmegaRange2<=pulse[3]  && pulse[3]<= OmegaRange3) ) // check same units 
    {
        PWM1_Start();
        PWM1_WriteCompare(1100); // motor goes mid
        PWM2_Start();
        PWM2_WriteCompare(1100); // motor goes mid
        //UART_PutString("MID\r\n");
    }    
}


void ClockWise(char Motor[12])
{
    if (strcmp(Motor,"M1")){
         PWM1_Start();
         
         PWM1_WriteCompare(CW);
         CyDelay(500);
 
    }
    if (strcmp(Motor,"M2")){
         PWM2_Start();
         PWM2_WriteCompare(CW); 

           
    }
}

void CounterClockWise(char Motor[12])
{
    if (strcmp(Motor,"M1")){
         PWM1_Start();
         PWM1_WriteCompare(CCW);

    }
    if (strcmp(Motor,"M2")){
         PWM2_Start();
         PWM2_WriteCompare(CCW); 
    }
}

CY_ISR(Sonic1_Interrupt)
{
    counts1 = 0;
    
    Pin1_Trigger_Write(1); // generating the pulse signal of 10 micro s
    CyDelayUs(10);
    Pin1_Trigger_Write(0);
    while(Pin1_Echo_Read() == 0) {} // waiting for the echo signal
    while(Pin1_Echo_Read() == 1) {counts1++;} // counts while echo signal equals to 1
    dist1=0.1356*counts1; // experimental otherwise coeff=340/2*10^(-6)*counts1
    
   //sprintf(TransmitBuffer, "D1: %i mm \r\n", dist1);
   //UART_PutString(TransmitBuffer);
    
    if (dist1<=distmax){LED_Write(1);PWM1_Stop();PWM2_Stop();UART_PutString("Obstacle detected on S1\r\n");} else {LED_Write(0);}
    
    
    Timer_ReadStatusRegister();  
}

CY_ISR(Sonic2_Interrupt)
{
    counts2 = 0;
 
    Pin2_Trigger_Write(1);
    CyDelayUs(10);
    Pin2_Trigger_Write(0);
    while(Pin2_Echo_Read() == 0){}
    while(Pin2_Echo_Read() == 1){counts2++;}
    dist2=0.1356*counts2;
    
    //sprintf(TransmitBuffer, "D2: %i mm \r\n", dist2);
    //UART_PutString(TransmitBuffer);
    
   if (dist2<=distmax){LED_Write(1);PWM1_Stop();PWM2_Stop();UART_PutString("Obstacle detected on S2\r\n");} else {LED_Write(0);}
    
    
    Timer_ReadStatusRegister();   
}

CY_ISR(IMU_Interrupt)
{ 
    // Get the raw values
    MPU6050_getMotion6(&CAX, &CAY, &CAZ, &CGX, &CGY, &CGZ); 
    raw_AX = (CAX-AXoff);
    raw_AY = (CAY-AYoff);//16384 is just 32768/2 to get our 1G value
    raw_AZ = (CAZ-(AZoff-16384)); //remove 1G before dividing
    raw_GX = (CGX-GXoff); //131.07 is just 32768/250 to get us our 1deg/sec value
    raw_GY = (CGY-GYoff);
    raw_GZ = (CGZ-GZoff);
    sprintf(TransmitBuffer, "%d,%d,%d,%d,%d,%d,%d,%d,%f,%f,%f,%f\t\r\n",(int)raw_AX,(int)raw_AY,(int)raw_AZ,(int)raw_GX,(int)raw_GY,(int)raw_GZ,(int)dist1,(int)dist2,Ome[1],Ome[2],Ome[3],Ome[4]);
    UART_PutString(TransmitBuffer);
    
    // Derive the angular velocity
   AngVelo(raw_GX,raw_GY,raw_GZ,Ome);
    
    // Act on the motor
   RotationMotor(Ome);
    
   // Clear the interrupt
   Timer_ReadStatusRegister();   
    
}

CY_ISR(Pin_SW1_Handler)
{
 UART_PutString("Starting the calibration ... \n\r");
 for(i=0; i<30; i++)
    {
      sprintf(TransmitBuffer, "Test Number: %d \n\r", i);
      UART_PutString(TransmitBuffer);
    
      MPU6050_getMotion6(&CAX, &CAY, &CAZ, &CGX, &CGY, &CGZ);
      AXoff += CAX;
      AYoff += CAY;
      AZoff += CAZ;
      GXoff += CGX;
      GYoff += CGY;
      GZoff += CGZ;
       
      sprintf(TransmitBuffer, "AX:%d, AY:%d, AZ:%d || GX:%d, GY:%d, GZ:%d,\t", CAX,CAY,CAZ,CGX,CGY,CGZ);
      UART_PutString(TransmitBuffer);
      UART_PutString("\n\r");
      CyDelay(100);
    }
    
    AXoff = AXoff/numberOfTests;
    AYoff = AYoff/numberOfTests;
    AZoff = AZoff/numberOfTests;
    GXoff = GXoff/numberOfTests;
    GYoff = GYoff/numberOfTests;
    GZoff = GZoff/numberOfTests;
    
    UART_PutString("\n\nTest finished, offset values are shown below\n\n\r");
    sprintf(TransmitBuffer, "AXoff:%d, AYoff:%d, AZoff:%d || GXoff:%d, GYoff:%d, GZoff:%d,\t", (int)AXoff,(int)AYoff,(int)AZoff,(int)GXoff,(int)GYoff,(int)GZoff);
    UART_PutString(TransmitBuffer);
        
 Pin_SW1_ClearInterrupt();
}

CY_ISR(Rx_Interrupt)
{
        rxData=UART_GetChar();
        
        UART_PutChar(rxData); //not useful, this is just to check that the command by the user is properly working
        //UART_1_PutString("Out of loop");
        char stop='s';
        char up='u';
        char down='d';
        char left='l';
        char right='r';
        char value='v';
       
        //UART_PutString("User command detected \r\n");
        
        if (rxData==stop){
            PWM1_Stop();
            PWM2_Stop();
            //UART_PutString("stop\r\n");
            
        }
        
        if (rxData==up){
            ClockWise("M1");
            ClockWise("M2");
            //UART_PutString("up\r\n");
        }
        
        if (rxData==down){
            ClockWise("M1");
            ClockWise("M2");
            //UART_PutString("down\r\n");      
        }
        
        if (rxData==left){
            CounterClockWise("M1");
            CounterClockWise("M2");      
            //UART_PutString("left\r\n");
        }
        
        if (rxData==right){
            CounterClockWise("M1");
            CounterClockWise("M2"); 
            //UART_PutString("right\r\n");
            
        }
        
        if (rxData==value){
            sprintf(TransmitBuffer, "%d,%d,%d,%d,%d,%d,%d,%d\t\r\n",(int)raw_AX,(int)raw_AY,(int)raw_AZ,(int)raw_GX,(int)raw_GY,(int)raw_GZ,(int)dist1,(int)dist2);
            UART_PutString(TransmitBuffer);
            
        }
        
        // else nothing happens
        else{
            
        }
        
        UART_ClearRxBuffer();
}

int main()
{ 
	I2C_MPU6050_Start();
    
    UART_Start();
	UART_Init();
    
    Timer_Start();
    
    MPU6050_init();
	MPU6050_initialize();
    
    PWM1_Start();
    PWM2_Start();
    
    Sonic1_Interrupt_Start();
    Sonic1_Interrupt_StartEx(Sonic1_Interrupt);
    Sonic1_Interrupt_Enable();
    
    Sonic2_Interrupt_Start();
    Sonic2_Interrupt_StartEx(Sonic2_Interrupt);
    Sonic2_Interrupt_Enable();
    
    IMU_Interrupt_Start();
    IMU_Interrupt_StartEx(IMU_Interrupt);
    IMU_Interrupt_Enable();
    
    Pin_SW1_Interrupt_Start();
    Pin_SW1_Interrupt_StartEx(Pin_SW1_Handler);
    Pin_SW1_Interrupt_Enable();
    
    Rx_Interrupt_Start();
    Rx_Interrupt_StartEx(Rx_Interrupt);
    Rx_Interrupt_Enable();
    
    UART_PutString("Connected\r\n");
    
    CyGlobalIntEnable;


    for(;;)
    {
    }
    
}


