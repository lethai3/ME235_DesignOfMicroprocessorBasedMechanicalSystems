/*******************************************************************************
* File Name: SERIAL_PM.c
* Version 2.50
*
* Description:
*  This file provides Sleep/WakeUp APIs functionality.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SERIAL.h"


/***************************************
* Local data allocation
***************************************/

static SERIAL_BACKUP_STRUCT  SERIAL_backup =
{
    /* enableState - disabled */
    0u,
};



/*******************************************************************************
* Function Name: SERIAL_SaveConfig
********************************************************************************
*
* Summary:
*  This function saves the component nonretention control register.
*  Does not save the FIFO which is a set of nonretention registers.
*  This function is called by the SERIAL_Sleep() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SERIAL_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void SERIAL_SaveConfig(void)
{
    #if(SERIAL_CONTROL_REG_REMOVED == 0u)
        SERIAL_backup.cr = SERIAL_CONTROL_REG;
    #endif /* End SERIAL_CONTROL_REG_REMOVED */
}


/*******************************************************************************
* Function Name: SERIAL_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the nonretention control register except FIFO.
*  Does not restore the FIFO which is a set of nonretention registers.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SERIAL_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
* Notes:
*  If this function is called without calling SERIAL_SaveConfig() 
*  first, the data loaded may be incorrect.
*
*******************************************************************************/
void SERIAL_RestoreConfig(void)
{
    #if(SERIAL_CONTROL_REG_REMOVED == 0u)
        SERIAL_CONTROL_REG = SERIAL_backup.cr;
    #endif /* End SERIAL_CONTROL_REG_REMOVED */
}


/*******************************************************************************
* Function Name: SERIAL_Sleep
********************************************************************************
*
* Summary:
*  This is the preferred API to prepare the component for sleep. 
*  The SERIAL_Sleep() API saves the current component state. Then it
*  calls the SERIAL_Stop() function and calls 
*  SERIAL_SaveConfig() to save the hardware configuration.
*  Call the SERIAL_Sleep() function before calling the CyPmSleep() 
*  or the CyPmHibernate() function. 
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SERIAL_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void SERIAL_Sleep(void)
{
    #if(SERIAL_RX_ENABLED || SERIAL_HD_ENABLED)
        if((SERIAL_RXSTATUS_ACTL_REG  & SERIAL_INT_ENABLE) != 0u)
        {
            SERIAL_backup.enableState = 1u;
        }
        else
        {
            SERIAL_backup.enableState = 0u;
        }
    #else
        if((SERIAL_TXSTATUS_ACTL_REG  & SERIAL_INT_ENABLE) !=0u)
        {
            SERIAL_backup.enableState = 1u;
        }
        else
        {
            SERIAL_backup.enableState = 0u;
        }
    #endif /* End SERIAL_RX_ENABLED || SERIAL_HD_ENABLED*/

    SERIAL_Stop();
    SERIAL_SaveConfig();
}


/*******************************************************************************
* Function Name: SERIAL_Wakeup
********************************************************************************
*
* Summary:
*  This is the preferred API to restore the component to the state when 
*  SERIAL_Sleep() was called. The SERIAL_Wakeup() function
*  calls the SERIAL_RestoreConfig() function to restore the 
*  configuration. If the component was enabled before the 
*  SERIAL_Sleep() function was called, the SERIAL_Wakeup()
*  function will also re-enable the component.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SERIAL_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void SERIAL_Wakeup(void)
{
    SERIAL_RestoreConfig();
    #if( (SERIAL_RX_ENABLED) || (SERIAL_HD_ENABLED) )
        SERIAL_ClearRxBuffer();
    #endif /* End (SERIAL_RX_ENABLED) || (SERIAL_HD_ENABLED) */
    #if(SERIAL_TX_ENABLED || SERIAL_HD_ENABLED)
        SERIAL_ClearTxBuffer();
    #endif /* End SERIAL_TX_ENABLED || SERIAL_HD_ENABLED */

    if(SERIAL_backup.enableState != 0u)
    {
        SERIAL_Enable();
    }
}


/* [] END OF FILE */
