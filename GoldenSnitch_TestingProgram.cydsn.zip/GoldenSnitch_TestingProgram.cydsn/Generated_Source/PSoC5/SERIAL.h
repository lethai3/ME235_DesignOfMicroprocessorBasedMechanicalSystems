/*******************************************************************************
* File Name: SERIAL.h
* Version 2.50
*
* Description:
*  Contains the function prototypes and constants available to the UART
*  user module.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/


#if !defined(CY_UART_SERIAL_H)
#define CY_UART_SERIAL_H

#include "cyfitter.h"
#include "cytypes.h"
#include "CyLib.h" /* For CyEnterCriticalSection() and CyExitCriticalSection() functions */


/***************************************
* Conditional Compilation Parameters
***************************************/

#define SERIAL_RX_ENABLED                     (0u)
#define SERIAL_TX_ENABLED                     (1u)
#define SERIAL_HD_ENABLED                     (0u)
#define SERIAL_RX_INTERRUPT_ENABLED           (0u)
#define SERIAL_TX_INTERRUPT_ENABLED           (0u)
#define SERIAL_INTERNAL_CLOCK_USED            (1u)
#define SERIAL_RXHW_ADDRESS_ENABLED           (0u)
#define SERIAL_OVER_SAMPLE_COUNT              (8u)
#define SERIAL_PARITY_TYPE                    (0u)
#define SERIAL_PARITY_TYPE_SW                 (0u)
#define SERIAL_BREAK_DETECT                   (0u)
#define SERIAL_BREAK_BITS_TX                  (13u)
#define SERIAL_BREAK_BITS_RX                  (13u)
#define SERIAL_TXCLKGEN_DP                    (1u)
#define SERIAL_USE23POLLING                   (1u)
#define SERIAL_FLOW_CONTROL                   (0u)
#define SERIAL_CLK_FREQ                       (0u)
#define SERIAL_TX_BUFFER_SIZE                 (4u)
#define SERIAL_RX_BUFFER_SIZE                 (4u)

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component UART_v2_50 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */

#if defined(SERIAL_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG)
    #define SERIAL_CONTROL_REG_REMOVED            (0u)
#else
    #define SERIAL_CONTROL_REG_REMOVED            (1u)
#endif /* End SERIAL_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */


/***************************************
*      Data Structure Definition
***************************************/

/* Sleep Mode API Support */
typedef struct SERIAL_backupStruct_
{
    uint8 enableState;

    #if(SERIAL_CONTROL_REG_REMOVED == 0u)
        uint8 cr;
    #endif /* End SERIAL_CONTROL_REG_REMOVED */

} SERIAL_BACKUP_STRUCT;


/***************************************
*       Function Prototypes
***************************************/

void SERIAL_Start(void) ;
void SERIAL_Stop(void) ;
uint8 SERIAL_ReadControlRegister(void) ;
void SERIAL_WriteControlRegister(uint8 control) ;

void SERIAL_Init(void) ;
void SERIAL_Enable(void) ;
void SERIAL_SaveConfig(void) ;
void SERIAL_RestoreConfig(void) ;
void SERIAL_Sleep(void) ;
void SERIAL_Wakeup(void) ;

/* Only if RX is enabled */
#if( (SERIAL_RX_ENABLED) || (SERIAL_HD_ENABLED) )

    #if (SERIAL_RX_INTERRUPT_ENABLED)
        #define SERIAL_EnableRxInt()  CyIntEnable (SERIAL_RX_VECT_NUM)
        #define SERIAL_DisableRxInt() CyIntDisable(SERIAL_RX_VECT_NUM)
        CY_ISR_PROTO(SERIAL_RXISR);
    #endif /* SERIAL_RX_INTERRUPT_ENABLED */

    void SERIAL_SetRxAddressMode(uint8 addressMode)
                                                           ;
    void SERIAL_SetRxAddress1(uint8 address) ;
    void SERIAL_SetRxAddress2(uint8 address) ;

    void  SERIAL_SetRxInterruptMode(uint8 intSrc) ;
    uint8 SERIAL_ReadRxData(void) ;
    uint8 SERIAL_ReadRxStatus(void) ;
    uint8 SERIAL_GetChar(void) ;
    uint16 SERIAL_GetByte(void) ;
    uint8 SERIAL_GetRxBufferSize(void)
                                                            ;
    void SERIAL_ClearRxBuffer(void) ;

    /* Obsolete functions, defines for backward compatible */
    #define SERIAL_GetRxInterruptSource   SERIAL_ReadRxStatus

#endif /* End (SERIAL_RX_ENABLED) || (SERIAL_HD_ENABLED) */

/* Only if TX is enabled */
#if(SERIAL_TX_ENABLED || SERIAL_HD_ENABLED)

    #if(SERIAL_TX_INTERRUPT_ENABLED)
        #define SERIAL_EnableTxInt()  CyIntEnable (SERIAL_TX_VECT_NUM)
        #define SERIAL_DisableTxInt() CyIntDisable(SERIAL_TX_VECT_NUM)
        #define SERIAL_SetPendingTxInt() CyIntSetPending(SERIAL_TX_VECT_NUM)
        #define SERIAL_ClearPendingTxInt() CyIntClearPending(SERIAL_TX_VECT_NUM)
        CY_ISR_PROTO(SERIAL_TXISR);
    #endif /* SERIAL_TX_INTERRUPT_ENABLED */

    void SERIAL_SetTxInterruptMode(uint8 intSrc) ;
    void SERIAL_WriteTxData(uint8 txDataByte) ;
    uint8 SERIAL_ReadTxStatus(void) ;
    void SERIAL_PutChar(uint8 txDataByte) ;
    void SERIAL_PutString(const char8 string[]) ;
    void SERIAL_PutArray(const uint8 string[], uint8 byteCount)
                                                            ;
    void SERIAL_PutCRLF(uint8 txDataByte) ;
    void SERIAL_ClearTxBuffer(void) ;
    void SERIAL_SetTxAddressMode(uint8 addressMode) ;
    void SERIAL_SendBreak(uint8 retMode) ;
    uint8 SERIAL_GetTxBufferSize(void)
                                                            ;
    /* Obsolete functions, defines for backward compatible */
    #define SERIAL_PutStringConst         SERIAL_PutString
    #define SERIAL_PutArrayConst          SERIAL_PutArray
    #define SERIAL_GetTxInterruptSource   SERIAL_ReadTxStatus

#endif /* End SERIAL_TX_ENABLED || SERIAL_HD_ENABLED */

#if(SERIAL_HD_ENABLED)
    void SERIAL_LoadRxConfig(void) ;
    void SERIAL_LoadTxConfig(void) ;
#endif /* End SERIAL_HD_ENABLED */


/* Communication bootloader APIs */
#if defined(CYDEV_BOOTLOADER_IO_COMP) && ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_SERIAL) || \
                                          (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface))
    /* Physical layer functions */
    void    SERIAL_CyBtldrCommStart(void) CYSMALL ;
    void    SERIAL_CyBtldrCommStop(void) CYSMALL ;
    void    SERIAL_CyBtldrCommReset(void) CYSMALL ;
    cystatus SERIAL_CyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;
    cystatus SERIAL_CyBtldrCommRead(uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;

    #if (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_SERIAL)
        #define CyBtldrCommStart    SERIAL_CyBtldrCommStart
        #define CyBtldrCommStop     SERIAL_CyBtldrCommStop
        #define CyBtldrCommReset    SERIAL_CyBtldrCommReset
        #define CyBtldrCommWrite    SERIAL_CyBtldrCommWrite
        #define CyBtldrCommRead     SERIAL_CyBtldrCommRead
    #endif  /* (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_SERIAL) */

    /* Byte to Byte time out for detecting end of block data from host */
    #define SERIAL_BYTE2BYTE_TIME_OUT (25u)
    #define SERIAL_PACKET_EOP         (0x17u) /* End of packet defined by bootloader */
    #define SERIAL_WAIT_EOP_DELAY     (5u)    /* Additional 5ms to wait for End of packet */
    #define SERIAL_BL_CHK_DELAY_MS    (1u)    /* Time Out quantity equal 1mS */

#endif /* CYDEV_BOOTLOADER_IO_COMP */


/***************************************
*          API Constants
***************************************/
/* Parameters for SetTxAddressMode API*/
#define SERIAL_SET_SPACE      (0x00u)
#define SERIAL_SET_MARK       (0x01u)

/* Status Register definitions */
#if( (SERIAL_TX_ENABLED) || (SERIAL_HD_ENABLED) )
    #if(SERIAL_TX_INTERRUPT_ENABLED)
        #define SERIAL_TX_VECT_NUM            (uint8)SERIAL_TXInternalInterrupt__INTC_NUMBER
        #define SERIAL_TX_PRIOR_NUM           (uint8)SERIAL_TXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* SERIAL_TX_INTERRUPT_ENABLED */

    #define SERIAL_TX_STS_COMPLETE_SHIFT          (0x00u)
    #define SERIAL_TX_STS_FIFO_EMPTY_SHIFT        (0x01u)
    #define SERIAL_TX_STS_FIFO_NOT_FULL_SHIFT     (0x03u)
    #if(SERIAL_TX_ENABLED)
        #define SERIAL_TX_STS_FIFO_FULL_SHIFT     (0x02u)
    #else /* (SERIAL_HD_ENABLED) */
        #define SERIAL_TX_STS_FIFO_FULL_SHIFT     (0x05u)  /* Needs MD=0 */
    #endif /* (SERIAL_TX_ENABLED) */

    #define SERIAL_TX_STS_COMPLETE            (uint8)(0x01u << SERIAL_TX_STS_COMPLETE_SHIFT)
    #define SERIAL_TX_STS_FIFO_EMPTY          (uint8)(0x01u << SERIAL_TX_STS_FIFO_EMPTY_SHIFT)
    #define SERIAL_TX_STS_FIFO_FULL           (uint8)(0x01u << SERIAL_TX_STS_FIFO_FULL_SHIFT)
    #define SERIAL_TX_STS_FIFO_NOT_FULL       (uint8)(0x01u << SERIAL_TX_STS_FIFO_NOT_FULL_SHIFT)
#endif /* End (SERIAL_TX_ENABLED) || (SERIAL_HD_ENABLED)*/

#if( (SERIAL_RX_ENABLED) || (SERIAL_HD_ENABLED) )
    #if(SERIAL_RX_INTERRUPT_ENABLED)
        #define SERIAL_RX_VECT_NUM            (uint8)SERIAL_RXInternalInterrupt__INTC_NUMBER
        #define SERIAL_RX_PRIOR_NUM           (uint8)SERIAL_RXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* SERIAL_RX_INTERRUPT_ENABLED */
    #define SERIAL_RX_STS_MRKSPC_SHIFT            (0x00u)
    #define SERIAL_RX_STS_BREAK_SHIFT             (0x01u)
    #define SERIAL_RX_STS_PAR_ERROR_SHIFT         (0x02u)
    #define SERIAL_RX_STS_STOP_ERROR_SHIFT        (0x03u)
    #define SERIAL_RX_STS_OVERRUN_SHIFT           (0x04u)
    #define SERIAL_RX_STS_FIFO_NOTEMPTY_SHIFT     (0x05u)
    #define SERIAL_RX_STS_ADDR_MATCH_SHIFT        (0x06u)
    #define SERIAL_RX_STS_SOFT_BUFF_OVER_SHIFT    (0x07u)

    #define SERIAL_RX_STS_MRKSPC           (uint8)(0x01u << SERIAL_RX_STS_MRKSPC_SHIFT)
    #define SERIAL_RX_STS_BREAK            (uint8)(0x01u << SERIAL_RX_STS_BREAK_SHIFT)
    #define SERIAL_RX_STS_PAR_ERROR        (uint8)(0x01u << SERIAL_RX_STS_PAR_ERROR_SHIFT)
    #define SERIAL_RX_STS_STOP_ERROR       (uint8)(0x01u << SERIAL_RX_STS_STOP_ERROR_SHIFT)
    #define SERIAL_RX_STS_OVERRUN          (uint8)(0x01u << SERIAL_RX_STS_OVERRUN_SHIFT)
    #define SERIAL_RX_STS_FIFO_NOTEMPTY    (uint8)(0x01u << SERIAL_RX_STS_FIFO_NOTEMPTY_SHIFT)
    #define SERIAL_RX_STS_ADDR_MATCH       (uint8)(0x01u << SERIAL_RX_STS_ADDR_MATCH_SHIFT)
    #define SERIAL_RX_STS_SOFT_BUFF_OVER   (uint8)(0x01u << SERIAL_RX_STS_SOFT_BUFF_OVER_SHIFT)
    #define SERIAL_RX_HW_MASK                     (0x7Fu)
#endif /* End (SERIAL_RX_ENABLED) || (SERIAL_HD_ENABLED) */

/* Control Register definitions */
#define SERIAL_CTRL_HD_SEND_SHIFT                 (0x00u) /* 1 enable TX part in Half Duplex mode */
#define SERIAL_CTRL_HD_SEND_BREAK_SHIFT           (0x01u) /* 1 send BREAK signal in Half Duplez mode */
#define SERIAL_CTRL_MARK_SHIFT                    (0x02u) /* 1 sets mark, 0 sets space */
#define SERIAL_CTRL_PARITY_TYPE0_SHIFT            (0x03u) /* Defines the type of parity implemented */
#define SERIAL_CTRL_PARITY_TYPE1_SHIFT            (0x04u) /* Defines the type of parity implemented */
#define SERIAL_CTRL_RXADDR_MODE0_SHIFT            (0x05u)
#define SERIAL_CTRL_RXADDR_MODE1_SHIFT            (0x06u)
#define SERIAL_CTRL_RXADDR_MODE2_SHIFT            (0x07u)

#define SERIAL_CTRL_HD_SEND               (uint8)(0x01u << SERIAL_CTRL_HD_SEND_SHIFT)
#define SERIAL_CTRL_HD_SEND_BREAK         (uint8)(0x01u << SERIAL_CTRL_HD_SEND_BREAK_SHIFT)
#define SERIAL_CTRL_MARK                  (uint8)(0x01u << SERIAL_CTRL_MARK_SHIFT)
#define SERIAL_CTRL_PARITY_TYPE_MASK      (uint8)(0x03u << SERIAL_CTRL_PARITY_TYPE0_SHIFT)
#define SERIAL_CTRL_RXADDR_MODE_MASK      (uint8)(0x07u << SERIAL_CTRL_RXADDR_MODE0_SHIFT)

/* StatusI Register Interrupt Enable Control Bits. As defined by the Register map for the AUX Control Register */
#define SERIAL_INT_ENABLE                         (0x10u)

/* Bit Counter (7-bit) Control Register Bit Definitions. As defined by the Register map for the AUX Control Register */
#define SERIAL_CNTR_ENABLE                        (0x20u)

/*   Constants for SendBreak() "retMode" parameter  */
#define SERIAL_SEND_BREAK                         (0x00u)
#define SERIAL_WAIT_FOR_COMPLETE_REINIT           (0x01u)
#define SERIAL_REINIT                             (0x02u)
#define SERIAL_SEND_WAIT_REINIT                   (0x03u)

#define SERIAL_OVER_SAMPLE_8                      (8u)
#define SERIAL_OVER_SAMPLE_16                     (16u)

#define SERIAL_BIT_CENTER                         (SERIAL_OVER_SAMPLE_COUNT - 2u)

#define SERIAL_FIFO_LENGTH                        (4u)
#define SERIAL_NUMBER_OF_START_BIT                (1u)
#define SERIAL_MAX_BYTE_VALUE                     (0xFFu)

/* 8X always for count7 implementation */
#define SERIAL_TXBITCTR_BREAKBITS8X   ((SERIAL_BREAK_BITS_TX * SERIAL_OVER_SAMPLE_8) - 1u)
/* 8X or 16X for DP implementation */
#define SERIAL_TXBITCTR_BREAKBITS ((SERIAL_BREAK_BITS_TX * SERIAL_OVER_SAMPLE_COUNT) - 1u)

#define SERIAL_HALF_BIT_COUNT   \
                            (((SERIAL_OVER_SAMPLE_COUNT / 2u) + (SERIAL_USE23POLLING * 1u)) - 2u)
#if (SERIAL_OVER_SAMPLE_COUNT == SERIAL_OVER_SAMPLE_8)
    #define SERIAL_HD_TXBITCTR_INIT   (((SERIAL_BREAK_BITS_TX + \
                            SERIAL_NUMBER_OF_START_BIT) * SERIAL_OVER_SAMPLE_COUNT) - 1u)

    /* This parameter is increased on the 2 in 2 out of 3 mode to sample voting in the middle */
    #define SERIAL_RXBITCTR_INIT  ((((SERIAL_BREAK_BITS_RX + SERIAL_NUMBER_OF_START_BIT) \
                            * SERIAL_OVER_SAMPLE_COUNT) + SERIAL_HALF_BIT_COUNT) - 1u)

#else /* SERIAL_OVER_SAMPLE_COUNT == SERIAL_OVER_SAMPLE_16 */
    #define SERIAL_HD_TXBITCTR_INIT   ((8u * SERIAL_OVER_SAMPLE_COUNT) - 1u)
    /* 7bit counter need one more bit for OverSampleCount = 16 */
    #define SERIAL_RXBITCTR_INIT      (((7u * SERIAL_OVER_SAMPLE_COUNT) - 1u) + \
                                                      SERIAL_HALF_BIT_COUNT)
#endif /* End SERIAL_OVER_SAMPLE_COUNT */

#define SERIAL_HD_RXBITCTR_INIT                   SERIAL_RXBITCTR_INIT


/***************************************
* Global variables external identifier
***************************************/

extern uint8 SERIAL_initVar;
#if (SERIAL_TX_INTERRUPT_ENABLED && SERIAL_TX_ENABLED)
    extern volatile uint8 SERIAL_txBuffer[SERIAL_TX_BUFFER_SIZE];
    extern volatile uint8 SERIAL_txBufferRead;
    extern uint8 SERIAL_txBufferWrite;
#endif /* (SERIAL_TX_INTERRUPT_ENABLED && SERIAL_TX_ENABLED) */
#if (SERIAL_RX_INTERRUPT_ENABLED && (SERIAL_RX_ENABLED || SERIAL_HD_ENABLED))
    extern uint8 SERIAL_errorStatus;
    extern volatile uint8 SERIAL_rxBuffer[SERIAL_RX_BUFFER_SIZE];
    extern volatile uint8 SERIAL_rxBufferRead;
    extern volatile uint8 SERIAL_rxBufferWrite;
    extern volatile uint8 SERIAL_rxBufferLoopDetect;
    extern volatile uint8 SERIAL_rxBufferOverflow;
    #if (SERIAL_RXHW_ADDRESS_ENABLED)
        extern volatile uint8 SERIAL_rxAddressMode;
        extern volatile uint8 SERIAL_rxAddressDetected;
    #endif /* (SERIAL_RXHW_ADDRESS_ENABLED) */
#endif /* (SERIAL_RX_INTERRUPT_ENABLED && (SERIAL_RX_ENABLED || SERIAL_HD_ENABLED)) */


/***************************************
* Enumerated Types and Parameters
***************************************/

#define SERIAL__B_UART__AM_SW_BYTE_BYTE 1
#define SERIAL__B_UART__AM_SW_DETECT_TO_BUFFER 2
#define SERIAL__B_UART__AM_HW_BYTE_BY_BYTE 3
#define SERIAL__B_UART__AM_HW_DETECT_TO_BUFFER 4
#define SERIAL__B_UART__AM_NONE 0

#define SERIAL__B_UART__NONE_REVB 0
#define SERIAL__B_UART__EVEN_REVB 1
#define SERIAL__B_UART__ODD_REVB 2
#define SERIAL__B_UART__MARK_SPACE_REVB 3



/***************************************
*    Initial Parameter Constants
***************************************/

/* UART shifts max 8 bits, Mark/Space functionality working if 9 selected */
#define SERIAL_NUMBER_OF_DATA_BITS    ((8u > 8u) ? 8u : 8u)
#define SERIAL_NUMBER_OF_STOP_BITS    (1u)

#if (SERIAL_RXHW_ADDRESS_ENABLED)
    #define SERIAL_RX_ADDRESS_MODE    (0u)
    #define SERIAL_RX_HW_ADDRESS1     (0u)
    #define SERIAL_RX_HW_ADDRESS2     (0u)
#endif /* (SERIAL_RXHW_ADDRESS_ENABLED) */

#define SERIAL_INIT_RX_INTERRUPTS_MASK \
                                  (uint8)((0 << SERIAL_RX_STS_FIFO_NOTEMPTY_SHIFT) \
                                        | (0 << SERIAL_RX_STS_MRKSPC_SHIFT) \
                                        | (0 << SERIAL_RX_STS_ADDR_MATCH_SHIFT) \
                                        | (0 << SERIAL_RX_STS_PAR_ERROR_SHIFT) \
                                        | (0 << SERIAL_RX_STS_STOP_ERROR_SHIFT) \
                                        | (0 << SERIAL_RX_STS_BREAK_SHIFT) \
                                        | (0 << SERIAL_RX_STS_OVERRUN_SHIFT))

#define SERIAL_INIT_TX_INTERRUPTS_MASK \
                                  (uint8)((0 << SERIAL_TX_STS_COMPLETE_SHIFT) \
                                        | (0 << SERIAL_TX_STS_FIFO_EMPTY_SHIFT) \
                                        | (0 << SERIAL_TX_STS_FIFO_FULL_SHIFT) \
                                        | (0 << SERIAL_TX_STS_FIFO_NOT_FULL_SHIFT))


/***************************************
*              Registers
***************************************/

#ifdef SERIAL_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define SERIAL_CONTROL_REG \
                            (* (reg8 *) SERIAL_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
    #define SERIAL_CONTROL_PTR \
                            (  (reg8 *) SERIAL_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
#endif /* End SERIAL_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(SERIAL_TX_ENABLED)
    #define SERIAL_TXDATA_REG          (* (reg8 *) SERIAL_BUART_sTX_TxShifter_u0__F0_REG)
    #define SERIAL_TXDATA_PTR          (  (reg8 *) SERIAL_BUART_sTX_TxShifter_u0__F0_REG)
    #define SERIAL_TXDATA_AUX_CTL_REG  (* (reg8 *) SERIAL_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define SERIAL_TXDATA_AUX_CTL_PTR  (  (reg8 *) SERIAL_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define SERIAL_TXSTATUS_REG        (* (reg8 *) SERIAL_BUART_sTX_TxSts__STATUS_REG)
    #define SERIAL_TXSTATUS_PTR        (  (reg8 *) SERIAL_BUART_sTX_TxSts__STATUS_REG)
    #define SERIAL_TXSTATUS_MASK_REG   (* (reg8 *) SERIAL_BUART_sTX_TxSts__MASK_REG)
    #define SERIAL_TXSTATUS_MASK_PTR   (  (reg8 *) SERIAL_BUART_sTX_TxSts__MASK_REG)
    #define SERIAL_TXSTATUS_ACTL_REG   (* (reg8 *) SERIAL_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)
    #define SERIAL_TXSTATUS_ACTL_PTR   (  (reg8 *) SERIAL_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)

    /* DP clock */
    #if(SERIAL_TXCLKGEN_DP)
        #define SERIAL_TXBITCLKGEN_CTR_REG        \
                                        (* (reg8 *) SERIAL_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define SERIAL_TXBITCLKGEN_CTR_PTR        \
                                        (  (reg8 *) SERIAL_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define SERIAL_TXBITCLKTX_COMPLETE_REG    \
                                        (* (reg8 *) SERIAL_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
        #define SERIAL_TXBITCLKTX_COMPLETE_PTR    \
                                        (  (reg8 *) SERIAL_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
    #else     /* Count7 clock*/
        #define SERIAL_TXBITCTR_PERIOD_REG    \
                                        (* (reg8 *) SERIAL_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define SERIAL_TXBITCTR_PERIOD_PTR    \
                                        (  (reg8 *) SERIAL_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define SERIAL_TXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) SERIAL_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define SERIAL_TXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) SERIAL_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define SERIAL_TXBITCTR_COUNTER_REG   \
                                        (* (reg8 *) SERIAL_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
        #define SERIAL_TXBITCTR_COUNTER_PTR   \
                                        (  (reg8 *) SERIAL_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
    #endif /* SERIAL_TXCLKGEN_DP */

#endif /* End SERIAL_TX_ENABLED */

#if(SERIAL_HD_ENABLED)

    #define SERIAL_TXDATA_REG             (* (reg8 *) SERIAL_BUART_sRX_RxShifter_u0__F1_REG )
    #define SERIAL_TXDATA_PTR             (  (reg8 *) SERIAL_BUART_sRX_RxShifter_u0__F1_REG )
    #define SERIAL_TXDATA_AUX_CTL_REG     (* (reg8 *) SERIAL_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)
    #define SERIAL_TXDATA_AUX_CTL_PTR     (  (reg8 *) SERIAL_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define SERIAL_TXSTATUS_REG           (* (reg8 *) SERIAL_BUART_sRX_RxSts__STATUS_REG )
    #define SERIAL_TXSTATUS_PTR           (  (reg8 *) SERIAL_BUART_sRX_RxSts__STATUS_REG )
    #define SERIAL_TXSTATUS_MASK_REG      (* (reg8 *) SERIAL_BUART_sRX_RxSts__MASK_REG )
    #define SERIAL_TXSTATUS_MASK_PTR      (  (reg8 *) SERIAL_BUART_sRX_RxSts__MASK_REG )
    #define SERIAL_TXSTATUS_ACTL_REG      (* (reg8 *) SERIAL_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define SERIAL_TXSTATUS_ACTL_PTR      (  (reg8 *) SERIAL_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End SERIAL_HD_ENABLED */

#if( (SERIAL_RX_ENABLED) || (SERIAL_HD_ENABLED) )
    #define SERIAL_RXDATA_REG             (* (reg8 *) SERIAL_BUART_sRX_RxShifter_u0__F0_REG )
    #define SERIAL_RXDATA_PTR             (  (reg8 *) SERIAL_BUART_sRX_RxShifter_u0__F0_REG )
    #define SERIAL_RXADDRESS1_REG         (* (reg8 *) SERIAL_BUART_sRX_RxShifter_u0__D0_REG )
    #define SERIAL_RXADDRESS1_PTR         (  (reg8 *) SERIAL_BUART_sRX_RxShifter_u0__D0_REG )
    #define SERIAL_RXADDRESS2_REG         (* (reg8 *) SERIAL_BUART_sRX_RxShifter_u0__D1_REG )
    #define SERIAL_RXADDRESS2_PTR         (  (reg8 *) SERIAL_BUART_sRX_RxShifter_u0__D1_REG )
    #define SERIAL_RXDATA_AUX_CTL_REG     (* (reg8 *) SERIAL_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define SERIAL_RXBITCTR_PERIOD_REG    (* (reg8 *) SERIAL_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define SERIAL_RXBITCTR_PERIOD_PTR    (  (reg8 *) SERIAL_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define SERIAL_RXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) SERIAL_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define SERIAL_RXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) SERIAL_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define SERIAL_RXBITCTR_COUNTER_REG   (* (reg8 *) SERIAL_BUART_sRX_RxBitCounter__COUNT_REG )
    #define SERIAL_RXBITCTR_COUNTER_PTR   (  (reg8 *) SERIAL_BUART_sRX_RxBitCounter__COUNT_REG )

    #define SERIAL_RXSTATUS_REG           (* (reg8 *) SERIAL_BUART_sRX_RxSts__STATUS_REG )
    #define SERIAL_RXSTATUS_PTR           (  (reg8 *) SERIAL_BUART_sRX_RxSts__STATUS_REG )
    #define SERIAL_RXSTATUS_MASK_REG      (* (reg8 *) SERIAL_BUART_sRX_RxSts__MASK_REG )
    #define SERIAL_RXSTATUS_MASK_PTR      (  (reg8 *) SERIAL_BUART_sRX_RxSts__MASK_REG )
    #define SERIAL_RXSTATUS_ACTL_REG      (* (reg8 *) SERIAL_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define SERIAL_RXSTATUS_ACTL_PTR      (  (reg8 *) SERIAL_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End  (SERIAL_RX_ENABLED) || (SERIAL_HD_ENABLED) */

#if(SERIAL_INTERNAL_CLOCK_USED)
    /* Register to enable or disable the digital clocks */
    #define SERIAL_INTCLOCK_CLKEN_REG     (* (reg8 *) SERIAL_IntClock__PM_ACT_CFG)
    #define SERIAL_INTCLOCK_CLKEN_PTR     (  (reg8 *) SERIAL_IntClock__PM_ACT_CFG)

    /* Clock mask for this clock. */
    #define SERIAL_INTCLOCK_CLKEN_MASK    SERIAL_IntClock__PM_ACT_MSK
#endif /* End SERIAL_INTERNAL_CLOCK_USED */


/***************************************
*       Register Constants
***************************************/

#if(SERIAL_TX_ENABLED)
    #define SERIAL_TX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End SERIAL_TX_ENABLED */

#if(SERIAL_HD_ENABLED)
    #define SERIAL_TX_FIFO_CLR            (0x02u) /* FIFO1 CLR */
#endif /* End SERIAL_HD_ENABLED */

#if( (SERIAL_RX_ENABLED) || (SERIAL_HD_ENABLED) )
    #define SERIAL_RX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End  (SERIAL_RX_ENABLED) || (SERIAL_HD_ENABLED) */


/***************************************
* The following code is DEPRECATED and
* should not be used in new projects.
***************************************/

/* UART v2_40 obsolete definitions */
#define SERIAL_WAIT_1_MS      SERIAL_BL_CHK_DELAY_MS   

#define SERIAL_TXBUFFERSIZE   SERIAL_TX_BUFFER_SIZE
#define SERIAL_RXBUFFERSIZE   SERIAL_RX_BUFFER_SIZE

#if (SERIAL_RXHW_ADDRESS_ENABLED)
    #define SERIAL_RXADDRESSMODE  SERIAL_RX_ADDRESS_MODE
    #define SERIAL_RXHWADDRESS1   SERIAL_RX_HW_ADDRESS1
    #define SERIAL_RXHWADDRESS2   SERIAL_RX_HW_ADDRESS2
    /* Backward compatible define */
    #define SERIAL_RXAddressMode  SERIAL_RXADDRESSMODE
#endif /* (SERIAL_RXHW_ADDRESS_ENABLED) */

/* UART v2_30 obsolete definitions */
#define SERIAL_initvar                    SERIAL_initVar

#define SERIAL_RX_Enabled                 SERIAL_RX_ENABLED
#define SERIAL_TX_Enabled                 SERIAL_TX_ENABLED
#define SERIAL_HD_Enabled                 SERIAL_HD_ENABLED
#define SERIAL_RX_IntInterruptEnabled     SERIAL_RX_INTERRUPT_ENABLED
#define SERIAL_TX_IntInterruptEnabled     SERIAL_TX_INTERRUPT_ENABLED
#define SERIAL_InternalClockUsed          SERIAL_INTERNAL_CLOCK_USED
#define SERIAL_RXHW_Address_Enabled       SERIAL_RXHW_ADDRESS_ENABLED
#define SERIAL_OverSampleCount            SERIAL_OVER_SAMPLE_COUNT
#define SERIAL_ParityType                 SERIAL_PARITY_TYPE

#if( SERIAL_TX_ENABLED && (SERIAL_TXBUFFERSIZE > SERIAL_FIFO_LENGTH))
    #define SERIAL_TXBUFFER               SERIAL_txBuffer
    #define SERIAL_TXBUFFERREAD           SERIAL_txBufferRead
    #define SERIAL_TXBUFFERWRITE          SERIAL_txBufferWrite
#endif /* End SERIAL_TX_ENABLED */
#if( ( SERIAL_RX_ENABLED || SERIAL_HD_ENABLED ) && \
     (SERIAL_RXBUFFERSIZE > SERIAL_FIFO_LENGTH) )
    #define SERIAL_RXBUFFER               SERIAL_rxBuffer
    #define SERIAL_RXBUFFERREAD           SERIAL_rxBufferRead
    #define SERIAL_RXBUFFERWRITE          SERIAL_rxBufferWrite
    #define SERIAL_RXBUFFERLOOPDETECT     SERIAL_rxBufferLoopDetect
    #define SERIAL_RXBUFFER_OVERFLOW      SERIAL_rxBufferOverflow
#endif /* End SERIAL_RX_ENABLED */

#ifdef SERIAL_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define SERIAL_CONTROL                SERIAL_CONTROL_REG
#endif /* End SERIAL_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(SERIAL_TX_ENABLED)
    #define SERIAL_TXDATA                 SERIAL_TXDATA_REG
    #define SERIAL_TXSTATUS               SERIAL_TXSTATUS_REG
    #define SERIAL_TXSTATUS_MASK          SERIAL_TXSTATUS_MASK_REG
    #define SERIAL_TXSTATUS_ACTL          SERIAL_TXSTATUS_ACTL_REG
    /* DP clock */
    #if(SERIAL_TXCLKGEN_DP)
        #define SERIAL_TXBITCLKGEN_CTR        SERIAL_TXBITCLKGEN_CTR_REG
        #define SERIAL_TXBITCLKTX_COMPLETE    SERIAL_TXBITCLKTX_COMPLETE_REG
    #else     /* Count7 clock*/
        #define SERIAL_TXBITCTR_PERIOD        SERIAL_TXBITCTR_PERIOD_REG
        #define SERIAL_TXBITCTR_CONTROL       SERIAL_TXBITCTR_CONTROL_REG
        #define SERIAL_TXBITCTR_COUNTER       SERIAL_TXBITCTR_COUNTER_REG
    #endif /* SERIAL_TXCLKGEN_DP */
#endif /* End SERIAL_TX_ENABLED */

#if(SERIAL_HD_ENABLED)
    #define SERIAL_TXDATA                 SERIAL_TXDATA_REG
    #define SERIAL_TXSTATUS               SERIAL_TXSTATUS_REG
    #define SERIAL_TXSTATUS_MASK          SERIAL_TXSTATUS_MASK_REG
    #define SERIAL_TXSTATUS_ACTL          SERIAL_TXSTATUS_ACTL_REG
#endif /* End SERIAL_HD_ENABLED */

#if( (SERIAL_RX_ENABLED) || (SERIAL_HD_ENABLED) )
    #define SERIAL_RXDATA                 SERIAL_RXDATA_REG
    #define SERIAL_RXADDRESS1             SERIAL_RXADDRESS1_REG
    #define SERIAL_RXADDRESS2             SERIAL_RXADDRESS2_REG
    #define SERIAL_RXBITCTR_PERIOD        SERIAL_RXBITCTR_PERIOD_REG
    #define SERIAL_RXBITCTR_CONTROL       SERIAL_RXBITCTR_CONTROL_REG
    #define SERIAL_RXBITCTR_COUNTER       SERIAL_RXBITCTR_COUNTER_REG
    #define SERIAL_RXSTATUS               SERIAL_RXSTATUS_REG
    #define SERIAL_RXSTATUS_MASK          SERIAL_RXSTATUS_MASK_REG
    #define SERIAL_RXSTATUS_ACTL          SERIAL_RXSTATUS_ACTL_REG
#endif /* End  (SERIAL_RX_ENABLED) || (SERIAL_HD_ENABLED) */

#if(SERIAL_INTERNAL_CLOCK_USED)
    #define SERIAL_INTCLOCK_CLKEN         SERIAL_INTCLOCK_CLKEN_REG
#endif /* End SERIAL_INTERNAL_CLOCK_USED */

#define SERIAL_WAIT_FOR_COMLETE_REINIT    SERIAL_WAIT_FOR_COMPLETE_REINIT

#endif  /* CY_UART_SERIAL_H */


/* [] END OF FILE */
